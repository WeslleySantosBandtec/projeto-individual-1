package com.projetoinvidual.projetoindividualcontinuada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoIndividualContinuadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoIndividualContinuadaApplication.class, args);
	}

}
