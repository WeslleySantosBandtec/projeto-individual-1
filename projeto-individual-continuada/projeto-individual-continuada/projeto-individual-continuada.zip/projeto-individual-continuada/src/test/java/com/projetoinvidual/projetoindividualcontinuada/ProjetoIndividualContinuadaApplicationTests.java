package com.projetoinvidual.projetoindividualcontinuada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoIndividualContinuadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
